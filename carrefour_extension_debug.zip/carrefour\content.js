// בדיקה אם אנחנו בדף של Carrefour
if (window.location.href.includes('carrefour.co.il')) {
  console.log('content.js: סקריפט התוכן נטען בדף של Carrefour', window.location.href);
  
  // רישום זיהוי חד ערכי של המופע של הסקריפט כדי לוודא שיש לנו גישה
  const scriptId = Math.random().toString(36).substring(2, 15);
  console.log('content.js: מזהה מופע סקריפט:', scriptId);
  
  // יצירת אלמנט תקשורת זמני להצגה
  const debugElement = document.createElement('div');
  debugElement.id = 'carrefour-extension-debug';
  debugElement.style.position = 'fixed';
  debugElement.style.bottom = '10px';
  debugElement.style.right = '10px';
  debugElement.style.zIndex = '10000';
  debugElement.style.backgroundColor = 'rgba(0,0,0,0.7)';
  debugElement.style.color = 'white';
  debugElement.style.padding = '5px';
  debugElement.style.fontSize = '10px';
  debugElement.style.borderRadius = '3px';
  debugElement.style.display = 'none';
  debugElement.textContent = `סקריפט פעיל (${scriptId})`;
  document.body.appendChild(debugElement);
  
  // להציג את אלמנט הדיבאג באלט+D
  document.addEventListener('keydown', function(e) {
    if (e.altKey && e.key === 'd') {
      debugElement.style.display = debugElement.style.display === 'none' ? 'block' : 'none';
    }
  });
  
  // האזנה להודעות מהחלון הקופץ
  chrome.runtime.onMessage.addListener(function(request, sender, sendResponse) {
    console.log(`content.js (${scriptId}): התקבלה הודעה:`, request);
    debugElement.textContent = `התקבלה הודעה: ${request.action} (${new Date().toLocaleTimeString()})`;
    
    try {
      if (request.action === "exportCart") {
        console.log('content.js: התקבלה בקשה לייצוא עגלה מהחלון הקופץ');
        exportCartToCsv();
        sendResponse({status: 'ok'});
        return true;
      }
      else if (request.action === "importCart") {
        console.log('content.js: התקבלה בקשה לייבוא עגלה מהחלון הקופץ', 
          request.data ? `(${request.data.length} פריטים)` : '(ללא נתונים)');
        
        if (request.data && Array.isArray(request.data) && request.data.length > 1) {
          importCartFromCsv(request.data);
          sendResponse({status: 'started'});
        } else {
          console.error('content.js: נתוני CSV לא תקינים:', request.data);
          sendResponse({error: 'נתונים לא תקינים'});
        }
        return true;
      }
      else {
        console.log('content.js: התקבלה פעולה לא מוכרת:', request.action);
        sendResponse({error: 'פעולה לא מוכרת'});
        return true;
      }
    } catch (error) {
      console.error('content.js: שגיאה בעת טיפול בהודעה:', error);
      sendResponse({error: error.message});
      return true;
    }
  });
  
  // בדיקה האם יש נתוני ייבוא מאוחסנים (למקרה שהדף רוענן)
  chrome.storage.local.get(['carrefour_csv_import_data'], function(data) {
    if (data.carrefour_csv_import_data) {
      console.log('content.js: נמצאו נתוני ייבוא מאוחסנים:', data.carrefour_csv_import_data.length);
      // יש לנו נתונים מאוחסנים, נתחיל את הייבוא אוטומטית
      if (confirm('נמצאו נתוני ייבוא CSV שטרם יובאו. האם להתחיל בייבוא כעת?')) {
        importCartFromCsv(data.carrefour_csv_import_data);
        // נקה את הנתונים המאוחסנים
        chrome.storage.local.remove(['carrefour_csv_import_data']);
      } else {
        // נקה את הנתונים המאוחסנים
        chrome.storage.local.remove(['carrefour_csv_import_data']);
      }
    }
  });
  
  // הוספת כפתור הייצוא לדף
  function addExportButton() {
    if (document.getElementById('carrefour-export-csv')) {
      return;
    }
    
    const button = document.createElement('button');
    button.id = 'carrefour-export-csv';
    button.textContent = 'ייצא לקובץ CSV';
    button.style.position = 'fixed';
    button.style.top = '10px';
    button.style.right = '10px';
    button.style.zIndex = '9999';
    button.style.padding = '10px 15px';
    button.style.backgroundColor = '#f39200'; // צבע קרפור
    button.style.color = 'white';
    button.style.border = 'none';
    button.style.borderRadius = '4px';
    button.style.cursor = 'pointer';
    button.style.fontWeight = 'bold';
    button.style.boxShadow = '0 2px 5px rgba(0,0,0,0.2)';
    
    button.addEventListener('mouseenter', function() {
      this.style.backgroundColor = '#e58a00';
    });
    
    button.addEventListener('mouseleave', function() {
      this.style.backgroundColor = '#f39200';
    });
    
    document.body.appendChild(button);
    
    button.addEventListener('click', exportCartToCsv);
    console.log('כפתור ייצוא CSV נוסף לדף העגלה');
  }

  // פונקציית הייצוא לCSV
  async function exportCartToCsv() {
    try {
      // עדכון הכפתור למצב טעינה
      const button = document.getElementById('carrefour-export-csv');
      if (button) {
        button.disabled = true;
        button.textContent = 'טוען...';
        button.style.backgroundColor = '#aaa';
      }
      
      // בקשת מידע מסקריפט הרקע
      const data = await new Promise(resolve => {
        chrome.runtime.sendMessage({action: "getCartData"}, response => {
          resolve(response);
        });
      });
      
      if (!data || !data.carrefour_auth_token || !data.carrefour_cart_details) {
        alert('לא נמצאו נתוני עגלה או טוקן אימות. נסה לרענן את הדף ולנסות שוב.');
        resetButton();
        return;
      }
      
      const authToken = data.carrefour_auth_token;
      const cartDetails = data.carrefour_cart_details;
      
      console.log('התקבלו נתוני עגלה:', cartDetails);
      
      // בניית URL לבקשה
      const apiUrl = `https://www.carrefour.co.il/v2/retailers/${cartDetails.retailerId}/branches/${cartDetails.branchId}/carts/${cartDetails.cartId}?appId=${cartDetails.appId}`;
      
      console.log('שולח בקשה אל:', apiUrl);
      
      // ביצוע הבקשה
      const response = await fetch(apiUrl, {
        method: "POST",
        headers: {
          "Content-Type": "application/json;charset=UTF-8",
          "Authorization": `Bearer ${authToken}`,
          "Accept": "application/json, text/plain, */*",
          "X-HTTP-Method-Override": "PATCH"
        },
        credentials: "include",
        body: JSON.stringify({})
      });
      
      if (!response.ok) {
        throw new Error(`שגיאת API: ${response.status} ${response.statusText}`);
      }
      
      const raw = await response.json();
      console.log('התקבלו נתוני עגלה מה-API');
      
      // עיבוד התשובה
      const lines = raw.cart.lines;
      
      if (!lines || lines.length === 0) {
        alert('העגלה ריקה או שלא התקבל מידע');
        resetButton();
        return;
      }

      const result = lines
        .filter(item => !item.text.includes("איסוף עצמי")) // דילוג על מוצרים לא רלוונטיים
        .map(item => ({
          שם: item.text,
          ברקוד: item.barcode,
          כמות: item.quantity,
          מחיר: item.unitPrice,
          'סה"כ': item.totalPrice,
          קישור: `https://www.carrefour.co.il/?catalogProduct=${item.product?.productId ?? ''}`,
          retailerProductId: item.product?.id ?? item.retailerProductId
        }));

      console.log(`נמצאו ${result.length} מוצרים בעגלה`);

      // יצירת קובץ CSV
      const headers = Object.keys(result[0]).join(',');
      const rows = result.map(obj => Object.values(obj).map(val =>
        `"${String(val).replace(/"/g, '""')}"`
      ).join(','));
      const csvContent = [headers, ...rows].join('\n');

      // הורדת הקובץ
      const blob = new Blob(["\uFEFF" + csvContent], { type: "text/csv;charset=utf-8;" });
      const link = document.createElement("a");
      link.href = URL.createObjectURL(blob);
      link.download = "carrefour_products.csv";
      document.body.appendChild(link);
      link.click();
      document.body.removeChild(link);
      
      console.log('קובץ CSV הורד בהצלחה');
      
      resetButton("ייצוא הושלם!");
      
      setTimeout(() => {
        resetButton();
      }, 2000);
      
    } catch (error) {
      console.error("שגיאה:", error);
      alert(`שגיאה: ${error.message}`);
      resetButton();
    }
  }
  
  // פונקציה לייבוא מוצרים מקובץ CSV לעגלה
  async function importCartFromCsv(csvData) {
    console.log('מתחיל בייבוא מוצרים מקובץ CSV', csvData.length);
    
    // יוצר דיאלוג התקדמות
    const progressModal = document.createElement('div');
    progressModal.id = 'import-progress-modal';
    progressModal.style.position = 'fixed';
    progressModal.style.top = '50%';
    progressModal.style.left = '50%';
    progressModal.style.transform = 'translate(-50%, -50%)';
    progressModal.style.backgroundColor = 'white';
    progressModal.style.padding = '20px';
    progressModal.style.borderRadius = '8px';
    progressModal.style.boxShadow = '0 0 10px rgba(0,0,0,0.3)';
    progressModal.style.zIndex = '10000';
    progressModal.style.minWidth = '300px';
    progressModal.style.direction = 'rtl';
    
    const progressTitle = document.createElement('h3');
    progressTitle.textContent = 'מייבא מוצרים לעגלה...';
    progressTitle.style.margin = '0 0 15px 0';
    progressTitle.style.color = '#333';
    
    const progressBar = document.createElement('div');
    progressBar.style.width = '100%';
    progressBar.style.height = '20px';
    progressBar.style.backgroundColor = '#f0f0f0';
    progressBar.style.borderRadius = '10px';
    progressBar.style.overflow = 'hidden';
    
    const progressFill = document.createElement('div');
    progressFill.style.width = '0%';
    progressFill.style.height = '100%';
    progressFill.style.backgroundColor = '#f39200';
    progressFill.style.transition = 'width 0.3s';
    
    const progressStatus = document.createElement('div');
    progressStatus.textContent = 'מתחיל בייבוא... (0/' + (csvData.length - 1) + ')';
    progressStatus.style.marginTop = '10px';
    progressStatus.style.fontSize = '14px';
    
    const closeButton = document.createElement('button');
    closeButton.textContent = 'סגור';
    closeButton.style.marginTop = '15px';
    closeButton.style.padding = '5px 10px';
    closeButton.style.backgroundColor = '#f0f0f0';
    closeButton.style.border = 'none';
    closeButton.style.borderRadius = '4px';
    closeButton.style.cursor = 'pointer';
    closeButton.style.display = 'none'; // יוצג רק בסיום
    
    closeButton.addEventListener('click', function() {
      document.body.removeChild(progressModal);
    });
    
    progressBar.appendChild(progressFill);
    progressModal.appendChild(progressTitle);
    progressModal.appendChild(progressBar);
    progressModal.appendChild(progressStatus);
    progressModal.appendChild(closeButton);
    
    document.body.appendChild(progressModal);
    
    // הכנת נתוני ה-CSV לעיבוד
    // שורה ראשונה מכילה כותרות
    const headers = csvData[0];
    const productRows = csvData.slice(1);
    
    console.log('כותרות הקובץ:', headers);
    
    // נמצא את האינדקסים של העמודות החשובות
    const nameIndex = headers.findIndex(h => h === 'product_name' || h === 'שם מוצר');
    const barcodeIndex = headers.findIndex(h => h === 'barcode' || h === 'ברקוד');
    const quantityIndex = headers.findIndex(h => h === 'quantity' || h === 'כמות');
    const linkIndex = headers.findIndex(h => h === 'product_link' || h === 'קישור מוצר');
    
    console.log('אינדקסים של עמודות:', { nameIndex, barcodeIndex, quantityIndex, linkIndex });
    
    // בדיקה שמצאנו את העמודות הדרושות
    if (nameIndex === -1 || quantityIndex === -1) {
      progressStatus.textContent = 'שגיאה: חסרות עמודות חובה בקובץ (שם מוצר, כמות)';
      progressTitle.textContent = 'שגיאה בייבוא';
      progressFill.style.backgroundColor = 'red';
      closeButton.style.display = 'block';
      console.error('חסרות עמודות חובה בקובץ ה-CSV');
      return;
    }
    
    // לולאה שמוסיפה את המוצרים אחד אחרי השני
    let currentIndex = 0;
    
    function addNextProduct() {
      if (currentIndex >= productRows.length) {
        // סיימנו להוסיף את כל המוצרים
        progressTitle.textContent = 'הייבוא הושלם בהצלחה';
        progressStatus.textContent = 'כל המוצרים יובאו לעגלה (' + currentIndex + '/' + productRows.length + ')';
        closeButton.style.display = 'block';
        return;
      }
      
      const row = productRows[currentIndex];
      const productName = row[nameIndex];
      const barcode = barcodeIndex !== -1 ? row[barcodeIndex] : '';
      const quantity = parseInt(row[quantityIndex]) || 1;
      const productLink = linkIndex !== -1 ? row[linkIndex] : '';
      
      console.log('מוסיף מוצר:', { productName, barcode, quantity, productLink });
      
      // עדכון התקדמות
      const progress = Math.round((currentIndex + 1) / productRows.length * 100);
      progressFill.style.width = progress + '%';
      progressStatus.textContent = 'מוסיף: ' + productName + ' (' + (currentIndex + 1) + '/' + productRows.length + ')';
      
      // לוגיקת הוספה לעגלה
      if (productLink) {
        // יש לנו קישור למוצר, נשתמש בו
        addProductByLink(productLink, quantity, function(success) {
          currentIndex++;
          setTimeout(addNextProduct, 500); // הוספת השהייה בין מוצרים
        });
      } else if (barcode) {
        // יש לנו ברקוד, ננסה להשתמש בו
        addProductByBarcode(barcode, quantity, function(success) {
          currentIndex++;
          setTimeout(addNextProduct, 500); // הוספת השהייה בין מוצרים
        });
      } else {
        // יש לנו רק שם, ננסה לחפש את המוצר
        addProductByName(productName, quantity, function(success) {
          currentIndex++;
          setTimeout(addNextProduct, 500); // הוספת השהייה בין מוצרים
        });
      }
    }
    
    // התחל את תהליך ההוספה
    setTimeout(addNextProduct, 500);
  }
  
  // פונקציה שמוסיפה מוצר לעגלה באמצעות קישור ישיר
  function addProductByLink(productLink, quantity, callback) {
    console.log('מוסיף מוצר לפי קישור:', productLink);
    
    // קבל את ה-token האחרון ששמור באחסון המקומי
    chrome.storage.local.get(['carrefour_token'], function(data) {
      if (!data.carrefour_token) {
        console.error('לא נמצא token בשמירה המקומית');
        callback(false);
        return;
      }
      
      // מקבל מזהה מוצר מהקישור
      const productId = extractProductIdFromLink(productLink);
      if (!productId) {
        console.error('לא הצלחנו לחלץ מזהה מוצר מהקישור:', productLink);
        callback(false);
        return;
      }
      
      // מבצע קריאה לממשק ה-API להוספת מוצר
      fetch(`https://www.carrefour.co.il/api/v1/cart/item?product_id=${productId}&quantity=${quantity}`, {
        method: 'POST',
        headers: {
          'Content-Type': 'application/json',
          'X-Auth-Token': data.carrefour_token
        }
      })
      .then(response => {
        if (response.ok) {
          console.log('המוצר נוסף בהצלחה:', productId);
          callback(true);
        } else {
          console.error('שגיאה בהוספת המוצר:', response.status);
          callback(false);
        }
      })
      .catch(error => {
        console.error('שגיאה בבקשת הוספת המוצר:', error);
        callback(false);
      });
    });
  }

  // פונקציה שמוסיפה מוצר לעגלה באמצעות ברקוד
  function addProductByBarcode(barcode, quantity, callback) {
    console.log('מוסיף מוצר לפי ברקוד:', barcode);
    
    // חיפוש מוצר לפי ברקוד
    fetch(`https://www.carrefour.co.il/api/v1/products/search?search=${barcode}`)
      .then(response => response.json())
      .then(data => {
        if (data && data.products && data.products.length > 0) {
          const productId = data.products[0].id;
          addProductByLink(`https://www.carrefour.co.il/product/${productId}`, quantity, callback);
        } else {
          console.error('לא נמצא מוצר עם ברקוד:', barcode);
          callback(false);
        }
      })
      .catch(error => {
        console.error('שגיאה בחיפוש מוצר לפי ברקוד:', error);
        callback(false);
      });
  }

  // פונקציה שמוסיפה מוצר לעגלה באמצעות שם
  function addProductByName(productName, quantity, callback) {
    console.log('מוסיף מוצר לפי שם:', productName);
    
    // חיפוש מוצר לפי שם
    fetch(`https://www.carrefour.co.il/api/v1/products/search?search=${encodeURIComponent(productName)}`)
      .then(response => response.json())
      .then(data => {
        if (data && data.products && data.products.length > 0) {
          const productId = data.products[0].id;
          addProductByLink(`https://www.carrefour.co.il/product/${productId}`, quantity, callback);
        } else {
          console.error('לא נמצא מוצר עם שם:', productName);
          callback(false);
        }
      })
      .catch(error => {
        console.error('שגיאה בחיפוש מוצר לפי שם:', error);
        callback(false);
      });
  }

  // פונקציה שמחלצת מזהה מוצר מקישור
  function extractProductIdFromLink(link) {
    try {
      // בדיקה אם הקישור מכיל מזהה מוצר
      const match = link.match(/\/product\/(\d+)/);
      if (match && match[1]) {
        return match[1];
      }
      
      // גם ננסה למצוא מזהה בחלק האחרון של ה-URL
      const parts = link.split('/');
      const lastPart = parts[parts.length - 1];
      if (/^\d+$/.test(lastPart)) {
        return lastPart;
      }
      
      return null;
    } catch (error) {
      console.error('שגיאה בחילוץ מזהה מוצר מקישור:', error);
      return null;
    }
  }
  
  function resetButton(text = 'ייצא לקובץ CSV') {
    const button = document.getElementById('carrefour-export-csv');
    if (button) {
      button.disabled = false;
      button.textContent = text;
      button.style.backgroundColor = '#f39200';
    }
  }
  
  // מחכה שהדף יסיים לטעון ואז מוסיף את הכפתור
  if (document.readyState === 'loading') {
    document.addEventListener('DOMContentLoaded', addExportButton);
  } else {
    addExportButton();
  }
} 